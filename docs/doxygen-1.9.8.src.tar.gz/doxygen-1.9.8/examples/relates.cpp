/*! 
 * A String class.
 */ 
  
class String
{
  friend int strcmp(const String &,const String &);
};

/*! 
 * Compares two strings.
 */

int strcmp(const String &s1,const String &s2)
{
}

/*! \relates String
 * A string debug function.
 */
void stringDebug()
{
}
