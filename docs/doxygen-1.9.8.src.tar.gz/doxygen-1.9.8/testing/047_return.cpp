// objective: test the \result, \return, and \returns commands
// check: 047__return_8cpp.xml

/** \file */

/** Test function 1.
 *  \result A integer.
 */
int func1();

/** Test function 2.
 *  \return A integer.
 */
int func2();

/** Test function 3.
 *  \returns A integer.
 */
int func3();

