void main()
{
  const char* a = "Some special character here:  ";

  Test t;
  t.example();
}

