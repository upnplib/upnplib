// objective: test a file with unicode characters in the name
// check: 061___xC3_x9Anicod_xE2_x82_xAC__file_8cpp.xml

class Test
{
};

