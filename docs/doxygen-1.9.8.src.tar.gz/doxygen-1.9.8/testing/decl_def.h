namespace N
{

/** @brief variable declaration */
extern int var;

/** @brief function declaration */
void foo(int param);

}
